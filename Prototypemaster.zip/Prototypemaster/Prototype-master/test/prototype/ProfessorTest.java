package padroescriacao.prototype;

import org.junit.jupiter.api.Test;
import prototype.Trabalhador;

import static org.junit.jupiter.api.Assertions.*;

class TrabalhadorTest {

    @Test
    void testClone() throws CloneNotSupportedException {
        Trabalhador Trabalahdor = new Trabalhador(123, "Trabalhador Original", new Empresa("CSN", 1), "Volta Redonda");

        Trabalhador trabalhadorClone = trabalahdor.clone();
        trabalhadorClone.setMatricula(456);
        trabalhadorClone.setNome("Trabalhador Clonado");
        trabalhadorClone.getEscola().setNumero(2);

        assertEquals("Professor{matricula=123, nome='Trabalhador Original', empresa=Empresa{logradouro='CSN', numero=1}, Escola='Volta Redonda'}", trabalhador.toString());
        assertEquals("Professor{matricula=456, nome='Trabalhador Clonado', empresa=Empresa{logradouro='CSN', numero=2}, Escola='Volta Redonda'}", trabalhadorClone.toString());
    }
}