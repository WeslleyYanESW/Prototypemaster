package prototype;

public class Trabalhador implements Cloneable {
    private int matricula;
    private String nome;
    private Empresa empresa;
    private String formacao;

    public Trabalhador(int matricula, String nome, Empresa empresa, String formacao) {
        this.matricula = matricula;
        this.nome = nome;
        this.empresa = empresa;
        this.formacao = formacao;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }

    @Override
    public Trabalhador clone() throws CloneNotSupportedException {
        Trabalhador TrabalhadorClone = (Trabalhador) super.clone();
        TrabalhadorClone.empresa = (Empresa) TrabalhadorClone.empresa.clone();
        return TrabalhadorClone;
    }

    @Override
    public String toString() {
        return "Trabalhador{" +
                "matricula=" + matricula +
                ", nome='" + nome + '\'' +
                ", empresa=" + empresa +
                ", Formacao='" + formacao + '\'' +
                '}';
    }
}